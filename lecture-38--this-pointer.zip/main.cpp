#include <iostream>

using namespace std;
class BankSystem {
    public:
        static int Employee;
        int Revenue;
        static int Objectcount;
        
        BankSystem(int Revenue) {
            this->Revenue = Revenue;
            Objectcount++;
        }
        static int getObjectCount() {
            return Objectcount;
        }
        static int getEmployee() {
            cout << "The same number of people work everywhere" << endl;
            return Employee;
        }
};

int BankSystem::Objectcount;
int BankSystem::Employee;

int main()
{
    BankSystem bank1(1);
    bank1.Revenue = 500;
    bank1.Employee = 50;
    cout << BankSystem::getEmployee() << endl;
    BankSystem bank2(1);
    bank2.Revenue = 200;
    bank2.Employee = 50;
    cout << BankSystem::getObjectCount() << endl;
    return 0;
}