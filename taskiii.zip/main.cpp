#include <iostream>

using namespace std;

class Triangle{
    public:
        int Side1;
        int Side2;
        int Side3;
        
        Triangle (int side1, int side2, int side3){
            Side1 = side1;
            Side2 = side2;
            Side3 = side3;
        }
        
        Triangle (int side1, int side2){
            Side1 = side1;
            Side2 = side2;
            Side3 = side2;
        }
        
        Triangle (int side1) {
            Side1 = side1;
            Side2 = side1;
            Side3 = side1;
        }
        
        int calculateParameter () {
            return Side1 + Side2 + Side3;
        }
};



int main()
{
    Triangle samkutxedi(4, 5, 6);
    Triangle tolferdaSamkutxedi(5, 6);
    Triangle tolgverdaSamkutxedi(7);

    cout << "samkutxedis parametria: " << samkutxedi.calculateParameter() << endl;
    cout << "tolgverda samkutxedis parametria: " << tolferdaSamkutxedi.calculateParameter() << endl;
    cout << "tolgverda samkutxedis parametria: " << tolgverdaSamkutxedi.calculateParameter() << endl;

    return 0;
}