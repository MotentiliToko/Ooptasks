#include <iostream>

using namespace std;
class Mother {
    public:
        int power;
        void method() {
            cout << "Funqcia nomeri erti" << endl;
        }
        Mother(int Power) {
            power = Power;
        };
};

class Father {
    public:
        int power2;
        void method() {
            cout << "Funqcia nomeri ori" << endl;
        }
        Father(int Power2) {
            power2 = Power2;
        };
};

class Child: public Mother, public Father {
    public:
        void method() {
            cout << "Funqcia nomeri sami" << endl;
        }
        Child(int Power, int Power2): Mother(Power), Father(Power2) {
            
        };
};

int main()
{   
    Child shvili(20,50);
    shvili.Mother::method();
    shvili.method();
    cout << shvili.power << endl;
    cout << shvili.power2 << endl;

    return 0;
}